# Declarando as variáveis

INDICE = 13
SOMA = 0
K = 0

#Laço de repetição: enquanto K for menor que INDICE
while K < INDICE:
    #É adicionado 1 ao valor de K
    K += 1
    #O valor de K é adicionado a SOMA
    SOMA += K

#Ao final da execução, será exibido o valor 91.
print(SOMA)